package com.example.form;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Intent intent = getIntent();
        TextView nama = findViewById(R.id.Namatext);
        TextView NIM = findViewById(R.id.NIMtext);
        TextView gender = findViewById(R.id.Gendertext);
        TextView umur = findViewById(R.id.textumur);

        nama.setText(intent.getStringExtra("Name"));
        NIM.setText(intent.getStringExtra("NIM"));
        gender.setText(intent.getStringExtra("gender"));
        umur.setText(intent.getStringExtra("Umur"));
    }


}