package com.example.form;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SeekBar umur = findViewById(R.id.barumur);
        TextView umurtext = findViewById(R.id.umurtext);
        umur.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                umurtext.setText(Integer.toString((umur.getProgress())));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    public void kirim(View v){
        EditText nama = findViewById(R.id.Namaedit);
        EditText nim = findViewById(R.id.NIMedit);
        RadioButton genderlaki = findViewById(R.id.Lakiradio);
        RadioButton genderpere = findViewById(R.id.Pereradio);
        SeekBar umur = findViewById(R.id.barumur);

        String gender = "";
        if (genderlaki.isChecked()){
            gender = "Laki-laki";
        }else if (genderpere.isChecked()){
            gender = "Perempuan";
        }
        Intent intent = new Intent(this, MainActivity2.class);
        intent.putExtra("Name",nama.getText().toString() );
        intent.putExtra("NIM",nim.getText().toString());
        intent.putExtra("gender",gender);
        intent.putExtra("Umur",Integer.toString(umur.getProgress()));
        startActivity(intent);


    }
}

